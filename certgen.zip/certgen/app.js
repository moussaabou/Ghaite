/**
 * Certificate Generator — app.js
 * Clean, modular, fully responsive
 */

'use strict';

/* ══════════════════════════════════════════
   STATE
══════════════════════════════════════════ */
const S = {
  img:        null,
  iw:         0,
  ih:         0,
  scale:      1,
  tx:         null,
  ty:         null,
  drag:       false,
  dox:        0,
  doy:        0,
  pinchDist:  null,
  startFs:    52,
  names:      [],
  idx:        0,
  fmt:        'png',   // 'png' | 'pdf'
  mode:       'zip',   // 'zip' | 'indv'
  bold:       false,
  italic:     false,
  underline:  false,
  align:      'center',
  theme:      'light',
  lastZip:    null,
  indvBlobs:  [],
  tab:        's',     // current mobile tab
};

/* ══════════════════════════════════════════
   DOM REFERENCES
══════════════════════════════════════════ */
const $ = id => document.getElementById(id);

const mc        = $('mc');
const ctx       = mc.getContext('2d', { alpha: false });
const dotEl     = $('dotEl');
const cwrapEl   = $('cwrapEl');
const mainEl    = $('mainEl');
const sbEl      = $('sbEl');
const emptyEl   = $('emptyEl');
const toolbarEl = $('toolbarEl');

/* ══════════════════════════════════════════
   UTILITIES
══════════════════════════════════════════ */
const isMob = () => window.innerWidth <= 768;
const tick  = ()  => new Promise(r => setTimeout(r, 0));
const safe  = n   => n.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').substring(0, 80);
const clamp = (v, min, max) => Math.max(min, Math.min(v, max));

function show(el, type = '') {
  if (!el) return;
  el.hidden = false;
  if (type) el.style.display = type;
}

function hide(el) {
  if (!el) return;
  el.hidden = true;
  el.style.display = '';
}

/* ══════════════════════════════════════════
   TOAST
══════════════════════════════════════════ */
function toast(msg, type = 'in') {
  const icons = { ok: '✅', err: '❌', in: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${icons[type] || 'ℹ️'} ${msg}`;
  $('toastsEl').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

/* ══════════════════════════════════════════
   THEME
══════════════════════════════════════════ */
function toggleTheme() {
  S.theme = S.theme === 'dark' ? 'light' : 'dark';
  document.body.setAttribute('data-theme', S.theme);
  const ico = S.theme === 'dark' ? '🌙' : '☀️';
  $('thIco').textContent    = ico;
  $('tIcoMob').textContent  = ico;
  // Update meta theme-color
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = S.theme === 'dark' ? '#0d1017' : '#ffffff';
}

/* ══════════════════════════════════════════
   MOBILE TABS
══════════════════════════════════════════ */
function switchMobTab(t) {
  if (!isMob()) return;
  S.tab = t;

  // Update tab buttons
  ['s','n','p','x','t'].forEach(x => {
    const el = $(`ti-${x}`);
    if (el) el.classList.toggle('active', x === t);
  });

  // Sidebar vs Main
  const inSb = (t === 's' || t === 'n');
  sbEl.classList.toggle('mob-on', inSb);
  mainEl.classList.toggle('mob-on', !inSb);

  // Sub-groups
  $('grpSettings').classList.toggle('mob-on', t === 's');
  $('grpNames').classList.toggle('mob-on', t === 'n');

  // Main panels
  const genPanel = $('genPanel');
  const resSec   = $('resSec');

  if (t === 'p') {
    // Preview tab
    if (genPanel) genPanel.hidden = true;
    cwrapEl.hidden  = !S.img;
    toolbarEl.hidden = !S.img;
    emptyEl.hidden   = !!S.img;
    if (resSec) resSec.style.display = resSec.classList.contains('show') ? 'block' : 'none';

  } else if (t === 'x') {
    // Export tab
    cwrapEl.hidden   = true;
    toolbarEl.hidden = true;
    emptyEl.hidden   = true;
    if (genPanel) { genPanel.hidden = false; }
    if (resSec) resSec.style.display = 'none';
    refreshMobStats();

  } else {
    if (genPanel) genPanel.hidden = true;
  }
}

function refreshMobStats() {
  const sv = (id, txt, good) => {
    const el = $(id);
    if (!el) return;
    el.textContent = txt;
    el.className   = `stat-val ${good ? 'ok' : 'err'}`;
  };
  sv('mS1', S.img       ? 'محمّلة ✓'         : 'غير محمّلة ✗', !!S.img);
  sv('mS2', S.tx !== null ? 'محدد ✓'          : 'لم يُحدد ✗',   S.tx !== null);
  sv('mS3', S.names.length ? `${S.names.length} اسم ✓` : 'لا يوجد ✗', S.names.length > 0);

  const hint   = $('mobHint');
  const ready  = S.img && S.tx !== null && S.names.length > 0;
  if (hint) {
    hint.textContent = ready
      ? `✅ جاهز — ${S.names.length} شهادة · ${S.mode === 'zip' ? 'ZIP واحد' : 'بطاقات فردية'} · ${S.fmt.toUpperCase()}`
      : `⚠️ يحتاج: ${[!S.img && 'صورة', S.tx === null && 'موضع', !S.names.length && 'أسماء'].filter(Boolean).join(' · ')}`;
  }
}

/* ══════════════════════════════════════════
   IMAGE UPLOAD
══════════════════════════════════════════ */
function initImageUpload() {
  const zone = $('imgZone');
  const input = $('imgIn');

  input.addEventListener('change', e => {
    if (e.target.files[0]) loadImg(e.target.files[0]);
  });

  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragenter', e => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('over');
    const f = e.dataTransfer.files[0];
    if (f && f.type.startsWith('image/')) loadImg(f);
  });
}

function loadImg(file) {
  toast('جاري تحميل الصورة...', 'in');
  const rd = new FileReader();
  rd.onload = ev => {
    const img = new Image();
    img.onload = () => {
      S.img = img;
      S.iw  = img.naturalWidth;
      S.ih  = img.naturalHeight;

      // Show info
      const ibox = $('ibox');
      if (ibox) ibox.hidden = false;
      $('imgDim').textContent = `${S.iw} × ${S.ih}`;
      $('imgFmt').textContent = file.name.split('.').pop().toUpperCase();

      requestAnimationFrame(() => requestAnimationFrame(() => {
        fitCanvas();
        setStep(2);
        toast('تم تحميل الصورة ✅', 'ok');
        if (isMob()) setTimeout(() => switchMobTab('p'), 300);
      }));
    };
    img.onerror = () => toast('فشل تحميل الصورة!', 'err');
    img.src = ev.target.result;
  };
  rd.readAsDataURL(file);
}

/* ══════════════════════════════════════════
   CANVAS FIT & DRAW
══════════════════════════════════════════ */
function fitCanvas() {
  if (!S.img) return;

  const mob    = isMob();
  const aw     = mainEl.clientWidth || window.innerWidth;
  const maxW   = Math.max(aw - (mob ? 16 : 80), 80);
  const mainH  = mob
    ? window.innerHeight - parseInt(getComputedStyle(document.documentElement).getPropertyValue('--hh')) - parseInt(getComputedStyle(document.documentElement).getPropertyValue('--th'))
    : mainEl.clientHeight || window.innerHeight;
  const maxH   = Math.max(mainH * (mob ? .55 : .75), 160);

  S.scale = clamp(Math.min(maxW / S.iw, maxH / S.ih, 1), .01, 4);

  mc.width  = Math.round(S.iw * S.scale);
  mc.height = Math.round(S.ih * S.scale);

  $('dimLbl').textContent  = `${S.iw} × ${S.ih} px`;
  $('zoomLbl').textContent = `${Math.round(S.scale * 100)}%`;

  emptyEl.hidden   = true;
  toolbarEl.hidden = false;
  cwrapEl.hidden   = false;

  draw();
}

function draw(nameOvr) {
  if (!S.img) return;

  // Background
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(S.img, 0, 0, mc.width, mc.height);

  if (S.tx === null) {
    dotEl.style.display = 'none';
    return;
  }

  // Name to render
  const nm = nameOvr !== undefined
    ? nameOvr
    : (S.names.length ? S.names[S.idx] : ($('smp').value || 'اسم المشارك'));

  const sz  = parseInt($('fs').value) || 52;
  const col = $('fc').value;
  const ff  = $('ff').value;
  const dsz = Math.max(1, Math.round(sz * S.scale));

  ctx.save();
  ctx.font         = `${S.italic ? 'italic' : 'normal'} ${S.bold ? 'bold' : 'normal'} ${dsz}px ${ff}`;
  ctx.fillStyle    = col;
  ctx.textAlign    = S.align;
  ctx.textBaseline = 'middle';

  const dx = Math.round(S.tx * S.scale);
  const dy = Math.round(S.ty * S.scale);

  if (S.underline) {
    const w  = ctx.measureText(nm).width;
    const sx = S.align === 'center' ? dx - w/2 : S.align === 'right' ? dx - w : dx;
    ctx.strokeStyle = col;
    ctx.lineWidth   = Math.max(1, dsz * .05);
    ctx.beginPath();
    ctx.moveTo(sx, dy + dsz * .56);
    ctx.lineTo(sx + w, dy + dsz * .56);
    ctx.stroke();
  }

  ctx.fillText(nm, dx, dy);
  ctx.restore();

  // Dot indicator
  dotEl.style.display = 'block';
  dotEl.style.left    = `${dx}px`;
  dotEl.style.top     = `${dy}px`;
}

/* ══════════════════════════════════════════
   CANVAS INTERACTION
══════════════════════════════════════════ */
function handleStart(mx, my) {
  if (!S.img) return;

  if (S.tx !== null) {
    const px  = S.tx * S.scale;
    const py  = S.ty * S.scale;
    const hit = isMob() ? 60 : 30;
    if (Math.abs(mx - px) < hit && Math.abs(my - py) < hit) {
      S.drag = true;
      S.dox  = mx - px;
      S.doy  = my - py;
      mc.style.cursor = 'grabbing';
      return;
    }
  }
  setPos(mx / S.scale, my / S.scale);
}

function handleMove(mx, my) {
  if (!S.drag) return;
  setPos((mx - S.dox) / S.scale, (my - S.doy) / S.scale);
}

function pinchDist(t1, t2) {
  return Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
}

// Mouse
mc.addEventListener('mousedown', e => {
  e.preventDefault();
  const r = mc.getBoundingClientRect();
  handleStart(e.clientX - r.left, e.clientY - r.top);
});
mc.addEventListener('mousemove', e => {
  const r = mc.getBoundingClientRect();
  handleMove(e.clientX - r.left, e.clientY - r.top);
});
mc.addEventListener('mouseup',    () => { S.drag = false; mc.style.cursor = 'crosshair'; });
mc.addEventListener('mouseleave', () => { S.drag = false; mc.style.cursor = 'crosshair'; });

// Touch
mc.addEventListener('touchstart', e => {
  e.preventDefault();
  const r = mc.getBoundingClientRect();
  if (e.touches.length === 1) {
    handleStart(e.touches[0].clientX - r.left, e.touches[0].clientY - r.top);
  } else if (e.touches.length === 2) {
    S.pinchDist = pinchDist(e.touches[0], e.touches[1]);
    S.startFs   = parseInt($('fs').value) || 52;
  }
}, { passive: false });

mc.addEventListener('touchmove', e => {
  e.preventDefault();
  const r = mc.getBoundingClientRect();
  if (e.touches.length === 1) {
    handleMove(e.touches[0].clientX - r.left, e.touches[0].clientY - r.top);
  } else if (e.touches.length === 2 && S.pinchDist) {
    const nd  = pinchDist(e.touches[0], e.touches[1]);
    const nfs = clamp(Math.round(S.startFs * nd / S.pinchDist), 8, 500);
    $('fs').value = nfs;
    draw();
  }
}, { passive: false });

mc.addEventListener('touchend', e => {
  if (e.touches.length < 2) S.pinchDist = null;
  if (e.touches.length === 0) S.drag = false;
});

function setPos(x, y) {
  S.tx = clamp(x, 0, S.iw);
  S.ty = clamp(y, 0, S.ih);

  $('px').value  = Math.round(S.tx);
  $('py').value  = Math.round(S.ty);
  $('pst').value = 'محدد ✓';
  $('modeLbl').textContent = '✓ محدد — اسحب للتعديل · إصبعان للحجم';
  $('modeLbl').style.color = 'var(--ok)';

  checkReady();
  draw();
}

function resetPos() {
  S.tx = S.ty = null;
  $('px').value  = '—';
  $('py').value  = '—';
  $('pst').value = 'لم يُحدد';
  $('modeLbl').textContent = '▶ اضغط لتحديد الموضع';
  $('modeLbl').style.color = '';
  checkReady();
  draw();
}

/* ══════════════════════════════════════════
   TEXT CONTROLS
══════════════════════════════════════════ */
function tog(k) {
  S[k] = !S[k];
  const map = { bold: 'bB', italic: 'bI', underline: 'bU' };
  const btn = $(map[k]);
  btn.classList.toggle('on', S[k]);
  btn.setAttribute('aria-pressed', S[k]);
  draw();
}

function aln(a) {
  S.align = a;
  [['C','center'], ['R','right'], ['L','left']].forEach(([x, v]) => {
    const btn = $(`a${x}`);
    btn.classList.toggle('on', v === a);
    btn.setAttribute('aria-pressed', v === a);
  });
  draw();
}

function onFontChange() {
  const ff   = $('ff').value;
  const fp   = $('fpTxt');
  const smp  = $('smp').value || 'أحمد بن علي — Ahmed Ali';
  fp.style.fontFamily = ff;
  fp.textContent = smp;
  draw();
}

function onSmpChange() {
  const v = $('smp').value || 'أحمد بن علي — Ahmed Ali';
  $('fpTxt').textContent = v;
  draw();
}

/* ══════════════════════════════════════════
   NAMES
══════════════════════════════════════════ */
function initNamesUpload() {
  const zone  = $('jsonZone');
  const input = $('jsonIn');

  input.addEventListener('change', e => {
    if (e.target.files[0]) readFile(e.target.files[0]);
  });

  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragenter', e => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('over');
    if (e.dataTransfer.files[0]) readFile(e.dataTransfer.files[0]);
  });
}

function readFile(file) {
  const r = new FileReader();
  r.onload = e => {
    const txt = e.target.result.trim();
    try {
      const d = JSON.parse(txt);
      if (!Array.isArray(d)) throw new Error('not array');
      S.names = d.map(x => x.name || x.Name || String(x)).filter(Boolean);
    } catch {
      // Plain text fallback
      S.names = txt.split('\n').map(l => l.trim()).filter(Boolean);
    }
    refreshNames();
    toast(`${S.names.length} اسم محمّل ✅`, 'ok');
  };
  r.onerror = () => toast('فشل قراءة الملف!', 'err');
  r.readAsText(file);
}

function onManual() {
  S.names = $('manual').value.split('\n').map(l => l.trim()).filter(Boolean);
  refreshNames();
}

function refreshNames() {
  const n      = S.names.length;
  const badge  = $('namesBadge');
  const navEl  = $('navEl');

  $('nCount').textContent = n;
  if (badge) badge.hidden = n === 0;
  if (navEl) navEl.hidden = n <= 1;

  S.idx = 0;
  updateNav();
  checkReady();
  if (n && S.img) draw(S.names[0]);
}

function nav(d) {
  if (!S.names.length) return;
  S.idx = (S.idx + d + S.names.length) % S.names.length;
  updateNav();
  draw(S.names[S.idx]);
}

function updateNav() {
  $('navLbl').value = `${S.idx + 1} / ${S.names.length}`;
}

/* ══════════════════════════════════════════
   FORMAT & MODE
══════════════════════════════════════════ */
function setFmt(f) {
  S.fmt = f;
  ['ePNG','ePDF','mePNG','mePDF'].forEach(id => {
    const el = $(id);
    if (!el) return;
    const on = id.toLowerCase().includes(f);
    el.classList.toggle('on', on);
    el.setAttribute('aria-pressed', on);
  });
}

function setMode(m) {
  S.mode = m;
  ['xmZip','xmIndv','mxmZip','mxmIndv'].forEach(id => {
    const el = $(id);
    if (!el) return;
    const on = id.toLowerCase().includes(m);
    el.classList.toggle('on', on);
    el.setAttribute('aria-pressed', on);
  });
  refreshMobStats();
}

/* ══════════════════════════════════════════
   READY CHECK
══════════════════════════════════════════ */
function checkReady() {
  const ready = !!(S.img && S.names.length > 0 && S.tx !== null);

  ['btnGen','mbtnGen'].forEach(id => {
    const el = $(id);
    if (el) {
      el.disabled = !ready;
      el.setAttribute('aria-disabled', !ready);
    }
  });

  const dot = $('rdot');
  if (dot) dot.classList.toggle('on', ready);

  if (S.img)          setStep(2);
  if (S.names.length) setStep(3);
  if (ready)          setStep(4);
}

/* ══════════════════════════════════════════
   RENDER HELPERS
══════════════════════════════════════════ */
function makePNG(name) {
  return new Promise(resolve => {
    const oc  = document.createElement('canvas');
    oc.width  = S.iw;
    oc.height = S.ih;
    const ox  = oc.getContext('2d', { alpha: false });

    ox.imageSmoothingEnabled = true;
    ox.imageSmoothingQuality = 'high';
    ox.drawImage(S.img, 0, 0, S.iw, S.ih);

    const sz  = parseInt($('fs').value) || 52;
    const col = $('fc').value;
    const ff  = $('ff').value;

    ox.save();
    ox.font         = `${S.italic ? 'italic' : 'normal'} ${S.bold ? 'bold' : 'normal'} ${sz}px ${ff}`;
    ox.fillStyle    = col;
    ox.textAlign    = S.align;
    ox.textBaseline = 'middle';

    if (S.underline) {
      const w  = ox.measureText(name).width;
      const sx = S.align === 'center' ? S.tx - w/2 : S.align === 'right' ? S.tx - w : S.tx;
      ox.strokeStyle = col;
      ox.lineWidth   = Math.max(1, sz * .05);
      ox.beginPath();
      ox.moveTo(sx, S.ty + sz * .56);
      ox.lineTo(sx + w, S.ty + sz * .56);
      ox.stroke();
    }

    ox.fillText(name, S.tx, S.ty);
    ox.restore();
    oc.toBlob(resolve, 'image/png', 1.0);
  });
}

async function makePDF(name) {
  const blob = await makePNG(name);
  const url  = URL.createObjectURL(blob);
  const pdf  = new window.jspdf.jsPDF({
    orientation: S.iw >= S.ih ? 'landscape' : 'portrait',
    unit:        'px',
    format:      [S.iw, S.ih],
    compress:    false,
  });
  pdf.addImage(url, 'PNG', 0, 0, S.iw, S.ih, '', 'NONE');
  URL.revokeObjectURL(url);
  return pdf.output('arraybuffer');
}

/* ══════════════════════════════════════════
   OVERLAY
══════════════════════════════════════════ */
function setOv(on, ttl = '', sub = '', pct = -1) {
  const ov = $('ovEl');
  ov.hidden = !on;

  if (ttl) $('ovTtl').textContent = ttl;
  if (sub !== '') $('ovSub').textContent = sub;
  if (pct >= 0)  { $('ovFill').style.width = `${pct}%`; }
}

/* ══════════════════════════════════════════
   PROGRESS BAR HELPERS
══════════════════════════════════════════ */
function setProgress(mob, pct, label) {
  const prefix = mob ? 'm' : 'd';
  const fill   = $(`${prefix}PFill`);
  const lbl    = $(`${prefix}PLbl`);
  if (fill) fill.style.width = `${pct}%`;
  if (lbl) lbl.textContent   = label;
}

function showProgress(mob, visible) {
  const wrap = $(mob ? 'mobProg' : 'dskProg');
  if (wrap) wrap.hidden = !visible;
}

/* ══════════════════════════════════════════
   MASTER GENERATE
══════════════════════════════════════════ */
async function generate() {
  if (!S.img || !S.names.length || S.tx === null) {
    toast('تأكد من الصورة والموضع وقائمة الأسماء', 'err');
    return;
  }
  if (S.mode === 'zip') await generateZip();
  else await generateIndv();
}

/* ── ZIP MODE ── */
async function generateZip() {
  const mob    = isMob();
  const banner = $('zipBanner');

  if (banner) banner.hidden = true;
  showProgress(mob, true);
  setOv(true, 'جاري التوليد...', '', 0);

  const zip   = new JSZip();
  const total = S.names.length;

  try {
    for (let i = 0; i < total; i++) {
      const name = S.names[i];
      const pct  = Math.round(i / total * 100);

      setOv(true, `(${i+1}/${total}) ${name}`, '', pct);
      setProgress(mob, pct, `${i+1} من ${total}`);
      await tick();

      const sn = safe(name);
      if (S.fmt === 'pdf') {
        zip.file(`${sn}.pdf`, await makePDF(name));
      } else {
        zip.file(`${sn}.png`, await makePNG(name));
      }
    }

    setOv(true, 'جاري ضغط الملفات...', '', 100);
    await tick();

    const zblob = await zip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    S.lastZip = zblob;
    setOv(false);
    showProgress(mob, false);

    if (mob && banner) {
      $('zBSub').textContent = `تم توليد ${total} شهادة — اضغط للتحميل`;
      banner.hidden = false;
      $('zBBtn').onclick = () => {
        saveAs(S.lastZip, 'certificates.zip');
        toast('جاري التحميل...', 'ok');
      };
    } else {
      saveAs(zblob, 'certificates.zip');
    }

    setStep(4);
    toast(`✅ ${total} شهادة في ZIP!`, 'ok');

  } catch (err) {
    console.error(err);
    toast(`خطأ: ${err.message}`, 'err');
    setOv(false);
    showProgress(mob, false);
  }
}

/* ── INDIVIDUAL MODE ── */
async function generateIndv() {
  const resSec  = $('resSec');
  const resGrid = $('resGrid');

  // Cleanup previous
  resGrid.innerHTML = '';
  resSec.classList.remove('show');
  resSec.hidden = true;
  S.indvBlobs.forEach(b => { try { URL.revokeObjectURL(b.url); } catch(e) {} });
  S.indvBlobs = [];

  const total = S.names.length;
  setOv(true, 'جاري التوليد...', '', 0);

  try {
    for (let i = 0; i < total; i++) {
      const name = S.names[i];
      setOv(true, `(${i+1}/${total}) ${name}`, '', Math.round(i / total * 100));
      await tick();

      let blob, ext;
      if (S.fmt === 'pdf') {
        blob = new Blob([await makePDF(name)], { type: 'application/pdf' });
        ext  = 'pdf';
      } else {
        blob = await makePNG(name);
        ext  = 'png';
      }

      const url = URL.createObjectURL(blob);
      const sn  = safe(name);
      S.indvBlobs.push({ name, sn, ext, url, blob });

      // Build card
      const card = buildResCard(name, sn, ext, url, blob, i);
      resGrid.appendChild(card);
    }

    setOv(false);

    $('resCount').textContent = total;
    resSec.hidden = false;
    resSec.classList.add('show');

    // Scroll into view
    if (isMob()) {
      switchMobTab('p');
      resSec.style.display = 'block';
      setTimeout(() => resSec.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200);
    } else {
      setTimeout(() => resSec.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }

    setStep(4);
    toast(`✅ ${total} شهادة — اضغط لتحميل كل واحدة`, 'ok');

  } catch (err) {
    console.error(err);
    toast(`خطأ: ${err.message}`, 'err');
    setOv(false);
  }
}

function buildResCard(name, sn, ext, url, blob, idx) {
  const card = document.createElement('div');
  card.className    = 'res-card';
  card.role         = 'listitem';
  card.style.animationDelay = `${idx * 30}ms`;

  // Thumbnail or placeholder
  if (ext === 'png') {
    const thumb    = document.createElement('img');
    thumb.className = 'res-thumb';
    thumb.src       = url;
    thumb.alt       = `شهادة ${name}`;
    thumb.title     = 'اضغط للمعاينة الكاملة';
    thumb.loading   = 'lazy';
    thumb.addEventListener('click', () => openLbox(url, name));
    card.appendChild(thumb);
  } else {
    const ph = document.createElement('div');
    ph.className  = 'res-pdf-ph';
    ph.innerHTML  = '📄';
    ph.setAttribute('aria-hidden', 'true');
    card.appendChild(ph);
  }

  // Card body
  const body  = document.createElement('div');
  body.className = 'res-body';

  const nm = document.createElement('div');
  nm.className   = 'res-name';
  nm.textContent = name;
  nm.title       = name;

  const dlBtn = document.createElement('button');
  dlBtn.className   = 'res-dl';
  dlBtn.innerHTML   = `${ext === 'pdf' ? '📄' : '🖼'} تحميل`;
  dlBtn.setAttribute('aria-label', `تحميل شهادة ${name}`);
  dlBtn.addEventListener('click', () => {
    saveAs(blob, `${sn}.${ext}`);
    dlBtn.innerHTML = '✅ تم التحميل';
    dlBtn.classList.add('done');
    setTimeout(() => {
      dlBtn.innerHTML = `${ext === 'pdf' ? '📄' : '🖼'} تحميل`;
      dlBtn.classList.remove('done');
    }, 2500);
  });

  body.appendChild(nm);
  body.appendChild(dlBtn);
  card.appendChild(body);

  return card;
}

function closeRes() {
  const resSec = $('resSec');
  resSec.classList.remove('show');
  resSec.hidden = true;
  $('resGrid').innerHTML = '';
  S.indvBlobs.forEach(b => { try { URL.revokeObjectURL(b.url); } catch(e) {} });
  S.indvBlobs = [];
}

/* ══════════════════════════════════════════
   LIGHTBOX
══════════════════════════════════════════ */
function openLbox(url, name) {
  const lb  = $('lbox');
  const img = $('lboxImg');
  img.src   = url;
  img.alt   = `معاينة شهادة ${name}`;
  lb.hidden = false;
  lb.classList.add('on');
  document.body.style.overflow = 'hidden';
}

function closeLbox() {
  const lb  = $('lbox');
  lb.hidden = true;
  lb.classList.remove('on');
  document.body.style.overflow = '';
}

function lboxClick(e) {
  if (e.target === $('lbox')) closeLbox();
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeLbox();
});

/* ══════════════════════════════════════════
   STEP INDICATOR
══════════════════════════════════════════ */
function setStep(n) {
  for (let i = 1; i <= 4; i++) {
    const el = $(`s${i}`);
    if (!el) continue;
    el.classList.toggle('active', i === n);
    el.classList.toggle('done',   i  < n);
  }
}

/* ══════════════════════════════════════════
   RESIZE
══════════════════════════════════════════ */
let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (S.img) fitCanvas();
  }, 120);
});

/* ══════════════════════════════════════════
   INIT
══════════════════════════════════════════ */
function init() {
  initImageUpload();
  initNamesUpload();

  // Mobile: start on settings tab, main hidden
  if (isMob()) {
    mainEl.classList.remove('mob-on');
    sbEl.classList.add('mob-on');
  }

  // Welcome toast
  toast('مرحباً! ارفع صورة الشهادة للبدء 🎓', 'in');
}

document.addEventListener('DOMContentLoaded', init);
